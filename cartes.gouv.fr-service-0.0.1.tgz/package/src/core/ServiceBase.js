import Users from '@/modules/Users';
import Documents from '@/modules/Documents';

import { useServiceStore } from '@/store/ServiceStore';
import { getSettings } from '@/core/extends/ExtendSettings';
import { logger } from '@/utils/logger';

// client keycloak pour vérifier la session (iframe)
import Keycloak from "keycloak-js";

const KEYCLOAK_SILENT_SSO_BLOCKED_KEY = 'auth:keycloak-silent-sso-blocked';

class ServiceBase {

  /** @type {import('@/core/extends/ExtendSettings').ServiceSettings} */
  settings

  #fetch
  #pending
  #emitter

  /**
   * Constructor for ServiceBase
   * @param {*} options 
   * @description
   * This class serves as a base for services that require user authentication 
   * and document management.
   * It initializes the service with options such as 
   * authentication status, user information, documents, and error handling.
   * It also sets the mode of operation (local or remote) and prepares the API URL.
   * The class includes methods for managing user access, such as checking 
   * if access is valid, getting login/logout information, and retrieving access tokens.
   */
  constructor(options) {
    options = options || {};
    this.settings = getSettings();

    /** authentification */
    this.authenticated = options.authenticated || false;
    
    /** user */
    this.user = options.user || {};
    /** documents */
    this.documents = options.documents || {};
    /** erreurs IAM */
    this.error = options.error || {};

    /** 
     * mode local ou remote 
     * on force toujours le mode d'authentification 
     * pour éviter les erreurs de configuration
     */
    this.mode = options.mode || this.settings.IamAuthMode;

    const baseUrl = this.settings.BaseUrl || '/';
    this.url = encodeURI(location.origin + baseUrl);
    this.api = null;

    // variables à instancier !
    this.#fetch = null;

    this.#pending = false;
    this.#emitter = options.emitter || null;

    return this;
  }

  /**
   * Get Fetch
   * @returns {Object} - fetch
   */
  getFetch () {
    this.#pending = true;
    return this.#fetch;
  }

  /**
   * Set Fetch
   * @param {Object} fetcher - fetch instance to sets 
   */
  setFetch (fetcher) {
    this.#fetch = fetcher;
  }

  /**
   * Save the current service state to the store
   * @description
   * This method saves the current state of the service instance
   * to the service store. It is typically called after any changes
   * to the service's properties to ensure that the latest state is persisted.
   * @returns {void}
   * @example 
   * // Usage:
   * const service = new ServiceBase();
   * service.saveStore();
   */
  saveStore () {
    var store = useServiceStore();
    store.setService(this);
    this.#pending = false;
  }

  /**
   * Throw an error
   * @param {*} error 
   */
  throwError (error) {
    this.#pending = false;
    throw error;
  }

  /**
   * Check if the service is pending
   * @returns {boolean} - true if pending, false otherwise
   */
  isPending () {
    return this.#pending;
  }
  
  /**
   * Stop the pending state
   * @description
   * This method sets the pending state of the service to false,
   * indicating that the service is no longer in a pending state.
   * It is typically called when an operation is completed or cancelled.
   * @returns {void}
   */
  stopPending () {
    this.#pending = false;
  }

  /**
   * Get emitter instance used to dispatch global events.
   * @returns {Object|null}
   */
  getEmitter () {
    return this.#emitter;
  }

  /**
   * Set emitter instance used to dispatch global events.
   * @param {Object|null} emitter
   */
  setEmitter (emitter) {
    this.#emitter = emitter || null;
  }

  /**
   * Verifie la session Keycloak en utilisant (iframe)
   * - soit avec la librairie Keycloak (par défaut)
   * - soit via la méthode oauth2  
   * @param {String} adapter - oauth2 or keycloak
   * @returns {Promise<Boolean>} - true if session is active, false otherwise
   */
  async checkKeycloakSession (adapter) {
    if (adapter === "keycloak") {
      const checkSsoClientId = this.settings.IamCheckSsoClientId || this.settings.IamClientId;

      const keycloakSilentSsoBlocked = sessionStorage.getItem(KEYCLOAK_SILENT_SSO_BLOCKED_KEY) === '1';
      if (keycloakSilentSsoBlocked) {
        return false;
      }

      logger.log("use checkKeycloakSessionAdapter keycloak");
      const keycloak = new Keycloak({
        url: this.settings.IamUrl || '',
        realm: this.settings.IamRealm || '',
        clientId: checkSsoClientId || ''
      });

      try {
        // INFO
        // https://www.keycloak.org/securing-apps/javascript-adapter#_browsers_with_blocked_third_party_cookies
        // Silent check-sso is not supported and falls back to regular (non-silent) check-sso by default. 
        // This behavior can be changed by setting silentCheckSsoFallback: false in the options passed 
        // to the init method. In this case, check-sso will be completely disabled if restrictive browser 
        // behavior is detected.
        return await keycloak.init({ 
            onLoad: 'check-sso', 
            flow: "standard",
            pkceMethod: "S256",
            checkLoginIframe: false,
            silentCheckSsoFallback: false,
            silentCheckSsoRedirectUri: this.url + '/silent-check-sso-keycloak.html'
        });
      } catch (error) {
        // @ts-ignore
        const message = String(error?.message || error || '');
        const isThirdPartyIframeTimeout = message.includes('3rd party check iframe message');

        if (isThirdPartyIframeTimeout) {
          sessionStorage.setItem(KEYCLOAK_SILENT_SSO_BLOCKED_KEY, '1');
          logger.warn('Silent SSO check skipped: browser blocks third-party storage/cookies (requestStorageAccess or iframe timeout).');
          return false;
        }

        throw error;
      }
    } else {
      logger.log("use checkKeycloakSessionAdapter oauth2");
      throw new Error("checkKeycloakSessionAdapter oauth2 is not implemented yet !");
    }
  }

  /**
   * Check if the access is valid
   * @returns {Promise} - Promise that resolves if access is valid, rejects otherwise
   */
  async resolveAccessStatus () {
    // Enregistrement du statut par defaut dans le storage 
    this.saveStore();
    return Promise.resolve();
  }
  /**
   * Get the access login
   * @returns {Promise} - Promise that resolves with the access login
   */
  async getAccessLogin () {
    return Promise.reject('this must be overridden !');
  }
  /**
   * Get the access logout
   * @returns {Promise} - Promise that resolves with the access logout
   */
  async getAccessLogout () {
    return Promise.reject('this must be overridden !');
  }
  /**
   * Get the access token
   * @returns {Promise} - Promise that resolves with the access token
   */
  async getAccessToken () {
    return Promise.reject('this must be overridden !');
  }
  /**
   * Check if the authentificate is already done locally
   * @returns {Boolean} - True if authentificate
   */
  isAuthenticatedLocally () {
    if (this.authenticated) {
      return true;
    }
    return false;
  }
  /**
   * Check if the authentificate is really done
   * @returns {Promise<Boolean>} - True if authentificate
   */
  async validateAuthentication () {
    try {
      // @ts-ignore
      var data = await this.getUserMe();
      return (data !== null);
    } catch {
      return false;
    }
  }
}

// Mixin
Object.assign(ServiceBase.prototype, Users);
Object.assign(ServiceBase.prototype, Documents);

export default ServiceBase;